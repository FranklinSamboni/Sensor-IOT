


#ifndef _RTL871X_QOS_H_
#define _RTL871X_QOS_H_
#include <drv_conf.h>
#include <osdep_service.h>






struct	qos_priv	{
	
	unsigned int	  qos_option;	//bit mask option: u-apsd, s-apsd, ts, block ack...		

};


#endif	//_RTL871X_QOS_H_

